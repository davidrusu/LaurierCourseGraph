LaurierCourseGraph
==================

Dependency Graph for Laurier Courses
